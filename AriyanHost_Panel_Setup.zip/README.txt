
Ariyan-Host Pterodactyl Panel Setup Guide:

1. Install Docker on your system.
2. Extract this zip.
3. Open terminal in this folder.
4. Run: docker compose up -d
5. Visit http://localhost:8080 in browser.

This will start your Ariyan-Host panel locally.

- Made for Aryan.
